README.txt

To run the program, simply hit run and enjoy the universe